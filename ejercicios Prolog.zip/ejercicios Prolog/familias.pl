hombre(antonio).
hombre(rafa).
hombre(joselito).
hombre(juanito).
hombre(lucho).
hombre(manuel).
hombre(carlos).
hombre(hector).
hombre(jaime).
hombre(oscar).
mujer(zaida).
mujer(ana).
mujer(angelica).
mujer(maria).
mujer(laura).
mujer(silvia).
mujer(tata).
mujer(angie).
mujer(luisa).
mujer(sofia).
mujer(diana).

progenitor(juanito,carlos).
progenitor(juanito,zaida).
progenitor(juanito,sebastian).
progenitor(maria,carlos).
progenitor(maria,zaida).
progenitor(maria,sebastian).
progenitor(carlos,antonio).
progenitor(carlos,laura).
progenitor(ana,antonio).
progenitor(ana,laura).
progenitor(sebastian,rafa).
progenitor(angelica,rafa).
progenitor(joselito,lucho).
progenitor(joselito,manuel).
progenitor(zaida,lucho).
progenitor(zaida,manuel).
progenitor(antonio,jaime).
progenitor(antonio,diana).
progenitor(silvia,jaime).
progenitor(silvia,diana).
progenitor(laura,hector).
progenitor(sofia,hector).
progenitor(rafa,oscar).
progenitor(tata,oscar).

pareja(X,Y) :- progenitor(X,Z),progenitor(Y,Z),X \== Y.
padre(X,Y):- hombre(X),progenitor(X,Y).
madre(X,Y):- mujer(X),progenitor(X,Y).
adoptado(A) :- progenitor(X,A),hombre(X),hombre(Y),pareja(X,Y).
adoptado(A) :- progenitor(X,A),mujer(X),mujer(Y),pareja(X,Y).
abuelo(X,Y) :- progenitor(X,Z) , progenitor(Z,Y).
bisabuelo(X,Y) :- progenitor(X,Z), abuelo(Z,Y).
bisnieto(X,Y) :- progenitor(Y,Z),abuelo(Z,X).
nieto(X,Y) :- progenitor(Y,Z),progenitor(Z,X).
hermano(X,Y) :- progenitor(Z,X),progenitor(Z,Y),X \== Y.
tio(X,Y) :- progenitor(Z,Y),hermano(Z,X).
cu�ado(X,Y) :- hermano(X,Z),pareja(Z,Y).
sobrino(X,Y):-progenitor(Z,X),hermano(Z,Y).
